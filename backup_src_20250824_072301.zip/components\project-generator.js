/**
 * project-generator.js
 * - generateDifficultyVariants(options)
 * - Uses @tonejs/midi for MIDI IO and local heuristics for polyphony reduction, quantize, and practice segmentation.
 *
 * Note: This module runs in the main process (Node) or in a renderer with Node enabled via preload.
 */

const fs = require('fs');
const path = require('path');
const { Midi } = require('@tonejs/midi');

/**
 * Quantize helper: quantize a time (seconds) to nearest grid
 * grid = fraction like "1/8" -> returns seconds by bpm
 */
function quantizeTime(timeSec, bpm, grid) {
    if (!grid) return timeSec;
    const [num, den] = grid.split('/').map(s => parseInt(s));
    const beatSec = 60.0 / bpm;
    const quantum = beatSec * (1 / (den / num)); // e.g., 1/8 -> beatSec/2? simpler: interpret '1/8' as eighth note -> beatSec/2
    // safer: treat grid '1/8' as fraction of whole note where whole note = 4 beats
    // Interpret as fraction of whole: whole = 4*beatSec
    const wholeSec = 4 * beatSec;
    const quant = wholeSec * (num / den);
    return Math.round(timeSec / quant) * quant;
}

function clampVelocity(v, minV, maxV) {
    return Math.max(minV, Math.min(maxV, Math.round(v)));
}

function millis(d) { return Math.round(d * 1000); }

/**
 * Load MIDI file and produce canonical notes array
 */
function parseMidiToNotes(midiPath) {
    const data = fs.readFileSync(midiPath);
    const midi = new Midi(data);
    const notes = [];
    midi.tracks.forEach((track, trackIndex) => {
        track.notes.forEach(n => {
            notes.push({
                pitch: n.midi,
                start: n.time,
                duration: n.duration,
                velocity: Math.round(n.velocity * 127),
                track: trackIndex
            });
        });
    });
    // sort by start time
    notes.sort((a,b) => a.start - b.start || b.duration - a.duration);
    return { notes, bpm: midi.header.tempos.length ? midi.header.tempos[0].bpm : 120, midi };
}

/**
 * Writes notes back to MIDI file with a single piano track
 */
function writeNotesToMidi(notes, outPath, bpm=120) {
    const midi = new Midi();
    midi.header.setTempo(bpm);
    const track = midi.addTrack();
    notes.forEach(n => {
        track.addNote({
            midi: n.pitch,
            time: n.start,
            duration: n.duration,
            velocity: (n.velocity || 90) / 127
        });
    });
    fs.writeFileSync(outPath, Buffer.from(midi.toArray()));
}

/**
 * Simple polyphony pruning: keep top N notes per time window by salience (duration * velocity)
 */
function prunePolyphony(notes, limitPerWindow = 1, windowSec = 0.5) {
    // notes assumed sorted by start
    const out = [];
    let i = 0;
    while (i < notes.length) {
        const t0 = notes[i].start;
        const window = notes.filter(n => n.start >= t0 && n.start < t0 + windowSec);
        // sort by salience
        window.sort((a,b) => (b.duration * b.velocity) - (a.duration * a.velocity));
        const keep = window.slice(0, limitPerWindow);
        // mark kept
        keep.forEach(k => out.push(Object.assign({}, k)));
        // advance i beyond window
        i = notes.findIndex(n => n.start >= t0 + windowSec);
        if (i === -1) break;
    }
    // deduplicate by start & pitch
    const seen = new Map();
    const final = [];
    out.forEach(n => {
        const key = `${n.start.toFixed(6)}_${n.pitch}`;
        if (!seen.has(key)) { seen.set(key, true); final.push(n); }
    });
    final.sort((a,b) => a.start - b.start);
    return final;
}

/**
 * Generate simple easy/medium/hard/practice variants
 */
async function generateDifficultyVariants({ projectDir, inputMidiPath, meta = {}, options = {} }) {
    if (!projectDir) throw new Error('projectDir required');
    if (!fs.existsSync(projectDir)) fs.mkdirSync(projectDir, { recursive: true });

    // Parse input
    if (!inputMidiPath || !fs.existsSync(inputMidiPath)) throw new Error('inputMidiPath missing or not found');

    const { notes: origNotes, bpm, midi } = parseMidiToNotes(inputMidiPath);
    const defaultBpm = meta.bpm || bpm || 120;

    // Parameters
    const polyphonyLimits = (options.polyphonyLimits) ? options.polyphonyLimits : { easy:1, medium:2, hard: Infinity };
    const quantizeGrid = (options.quantizeGrid) ? options.quantizeGrid : { easy: '1/8', medium: '1/16', hard: null };
    const minNoteLenMs = options.minNoteLenMs || 60;
    const phraseLengthSec = options.phraseLengthSec || 8;

    // Helper to filter ornaments
    function dropOrnaments(notes) {
        return notes.filter(n => millis(n.duration) >= minNoteLenMs);
    }

    // EASY
    let easyNotes = dropOrnaments(origNotes);
    easyNotes = prunePolyphony(easyNotes, polyphonyLimits.easy, 0.5);
    if (quantizeGrid.easy) {
        easyNotes = easyNotes.map(n => ({
            ...n,
            start: quantizeTime(n.start, defaultBpm, quantizeGrid.easy),
            duration: Math.max(0.05, quantizeTime(n.duration, defaultBpm, '1/16')) // quantize durations coarsely
        }));
    }

    // MEDIUM
    let mediumNotes = dropOrnaments(origNotes);
    mediumNotes = prunePolyphony(mediumNotes, polyphonyLimits.medium, 0.25);
    if (quantizeGrid.medium) {
        mediumNotes = mediumNotes.map(n => ({
            ...n,
            start: quantizeTime(n.start, defaultBpm, quantizeGrid.medium),
            duration: Math.max(0.04, quantizeTime(n.duration, defaultBpm, '1/32'))
        }));
    }

    // HARD - keep original but remove extremely short noise notes
    let hardNotes = origNotes.filter(n => millis(n.duration) >= 10);

    // PRACTICE - create phrase segments and produce left/right reduced tracks
    const practiceSegments = [];
    let cursor = 0;
    while (cursor < origNotes.length) {
        const segStart = origNotes[cursor].start;
        const segEnd = segStart + phraseLengthSec;
        const segNotes = origNotes.filter(n => n.start >= segStart && n.start < segEnd);
        if (segNotes.length === 0) { cursor++; continue; }
        practiceSegments.push(segNotes.map(n => ({...n})));
        // advance to next phrase
        cursor = origNotes.findIndex(n => n.start >= segEnd);
        if (cursor === -1) break;
    }
    // Merge practice segments into single practice track by concatenation (with small gap)
    const practiceNotes = [];
    let base = 0;
    for (let seg of practiceSegments) {
        if (seg.length === 0) continue;
        // shift to base
        const minStart = Math.min(...seg.map(n=>n.start));
        seg.forEach(n => {
            practiceNotes.push({
                pitch: n.pitch,
                start: (n.start - minStart) + base,
                duration: n.duration,
                velocity: n.velocity
            });
        });
        base += phraseLengthSec + 1.0; // 1s gap between phrases
    }

    // Clamp velocities and ensure pitch range
    const clampAndFix = (arr) => arr.map(n => ({
        pitch: Math.max(21, Math.min(108, Math.round(n.pitch))),
        start: Math.max(0, n.start),
        duration: Math.max(0.01, n.duration),
        velocity: clampVelocity(n.velocity||90, 40, 115)
    }));

    easyNotes = clampAndFix(easyNotes);
    mediumNotes = clampAndFix(mediumNotes);
    hardNotes = clampAndFix(hardNotes);
    const practiceNotesClamped = clampAndFix(practiceNotes);

    // Output paths
    const easyPath = path.join(projectDir, 'easy_auto.mid');
    const mediumPath = path.join(projectDir, 'medium_auto.mid');
    const hardPath = path.join(projectDir, 'hard_auto.mid');
    const practicePath = path.join(projectDir, 'practice_auto.mid');

    writeNotesToMidi(easyNotes, easyPath, defaultBpm);
    writeNotesToMidi(mediumNotes, mediumPath, defaultBpm);
    writeNotesToMidi(hardNotes, hardPath, defaultBpm);
    writeNotesToMidi(practiceNotesClamped, practicePath, defaultBpm);

    // Write arrangement JSONs (simple format)
    const writeArr = (arr, p) => {
        const manifest = { notes: arr.map(n => ({ pitch: n.pitch, start: n.start, duration: n.duration, velocity: n.velocity })) };
        fs.writeFileSync(p, JSON.stringify(manifest, null, 2), 'utf8');
    };
    writeArr(easyNotes, path.join(projectDir, 'easy.json'));
    writeArr(mediumNotes, path.join(projectDir, 'medium.json'));
    writeArr(hardNotes, path.join(projectDir, 'hard.json'));
    writeArr(practiceNotesClamped, path.join(projectDir, 'practice.json'));

    return {
        easyPath, mediumPath, hardPath, practicePath,
        notesCount: { easy: easyNotes.length, medium: mediumNotes.length, hard: hardNotes.length, practice: practiceNotesClamped.length },
        bpm: defaultBpm
    };
}

module.exports = {
    generateDifficultyVariants
};