/*
 src/main.js - Electron main process
 Secure: contextIsolation=true, nodeIntegration=false
 Exposes dialog IPC and delegates heavy generators to Node modules (project-generator)
*/
const { app, BrowserWindow, ipcMain, dialog } = require("electron");
const path = require("path");
const fs = require("fs");

let mainWindow;
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 820,
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      preload: path.join(__dirname, "preload.js")
    }
  });
  mainWindow.loadFile(path.join(__dirname, "renderer", "index.html"));
  // mainWindow.webContents.openDevTools();
}

app.whenReady().then(createWindow);
app.on("window-all-closed", () => { if (process.platform !== "darwin") app.quit(); });

// Dialog IPC
ipcMain.handle("dialog:openFolder", async () => {
  const res = await dialog.showOpenDialog(mainWindow, { properties: ["openDirectory"] });
  if (res.canceled) return { canceled: true };
  return { canceled: false, filePaths: res.filePaths };
});

ipcMain.handle("dialog:openFile", async (ev, filters = [{ name: "MIDI", extensions: ["mid","midi"] }]) => {
  const res = await dialog.showOpenDialog(mainWindow, { properties: ["openFile"], filters });
  if (res.canceled) return { canceled: true };
  return { canceled: false, filePaths: res.filePaths };
});

ipcMain.handle("dialog:saveFile", async (ev, opts = {}) => {
  const res = await dialog.showSaveDialog(mainWindow, opts);
  if (res.canceled) return { canceled: true };
  return { canceled: false, filePath: res.filePath };
});

// Project operations (run in Node context)
ipcMain.handle("load-project", async (ev, projectPath) => {
  try {
    const pj = path.join(projectPath, "project.json");
    if (!fs.existsSync(pj)) throw new Error("project.json not found");
    const raw = fs.readFileSync(pj, "utf8").replace(/^\uFEFF/, "");
    const project = JSON.parse(raw);
    return { ok: true, project };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

ipcMain.handle("generate-variants", async (ev, opts) => {
  try {
    const genPath = path.join(__dirname, "components", "project-generator.js");
    if (!fs.existsSync(genPath)) throw new Error("project-generator not found");
    const generator = require(genPath);
    const result = await generator.generateDifficultyVariants(opts);
    return { ok: true, result };
  } catch (e) {
    return { ok: false, error: e.message, stack: e.stack };
  }
});

ipcMain.handle("repair-project", async (ev, projectPath) => {
  try {
    const loaderPath = path.join(__dirname, "components", "project-loader.js");
    if (!fs.existsSync(loaderPath)) throw new Error("project-loader not found");
    const loader = require(loaderPath);
    const res = await loader.repairProject(projectPath);
    return { ok: true, result: res };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});