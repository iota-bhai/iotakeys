/* src/renderer/renderer.js
   Defensive wiring: toasts, audio unlock, non-blocking, no alerts/prompts.
*/
window.addEventListener("DOMContentLoaded", async () => {
  console.log("Renderer booting...");

  // Toast container
  (function createToastContainer() {
    if (document.getElementById("__toast_container")) return;
    const c = document.createElement("div");
    c.id = "__toast_container";
    c.style.position = "fixed";
    c.style.right = "16px";
    c.style.bottom = "20px";
    c.style.zIndex = "99999";
    c.style.maxWidth = "320px";
    c.style.pointerEvents = "none";
    document.body.appendChild(c);
  })();
  function toast(msg, ms = 3000) {
    const c = document.getElementById("__toast_container");
    if (!c) { console.log("Toast:", msg); return; }
    const el = document.createElement("div");
    el.textContent = msg;
    el.style.background = "rgba(15,20,25,0.95)";
    el.style.color = "#e6eef6";
    el.style.padding = "8px 12px";
    el.style.marginTop = "8px";
    el.style.borderRadius = "8px";
    el.style.boxShadow = "0 6px 18px rgba(0,0,0,0.6)";
    el.style.pointerEvents = "auto";
    el.style.fontSize = "13px";
    el.style.opacity = "0";
    el.style.transition = "opacity 180ms ease, transform 180ms ease";
    el.style.transform = "translateY(6px)";
    c.appendChild(el);
    requestAnimationFrame(() => { el.style.opacity = "1"; el.style.transform = "translateY(0px)"; });
    setTimeout(() => {
      el.style.opacity = "0"; el.style.transform = "translateY(6px)";
      setTimeout(()=> el.remove(), 220);
    }, ms);
  }

  // Audio unlock helper
  async function ensureAudioUnlocked() {
    if (window.__audioUnlocked) return;
    try {
      if (window.__robust && typeof window.__robust.resume === "function") {
        await window.__robust.resume();
      } else if (window.__robust && window.__robust.ctx && window.__robust.ctx.state === "suspended") {
        await window.__robust.ctx.resume();
      } else if (window.AudioContext || window.webkitAudioContext) {
        // fallback
        try { const ctx = new (window.AudioContext || window.webkitAudioContext)(); if (ctx.state === "suspended") await ctx.resume(); } catch(e) {}
      }
    } catch (e) { console.warn("Audio unlock/resume failed:", e); }
    window.__audioUnlocked = true;
    document.removeEventListener("pointerdown", unlockListener);
    document.removeEventListener("keydown", unlockListener);
  }
  const unlockListener = () => { ensureAudioUnlocked().catch(()=>{}); };
  document.addEventListener("pointerdown", unlockListener, { once: false });
  document.addEventListener("keydown", unlockListener, { once: false });

  // init audio engine if available
  if (window.RobustAudioEngine) {
    try { window.__robust = new window.RobustAudioEngine(); if (typeof window.__robust.init === "function") window.__robust.init(); console.log("RobustAudioEngine initialized"); } catch(e) { console.warn("Audio init failed:", e); }
  }

  // piano init (61 keys)
  const pianoContainer = document.getElementById("piano-panel");
  if (window.PianoComponent && pianoContainer) {
    try {
      window._piano = new window.PianoComponent(pianoContainer, { lowestMidi: 36, keyCount: 61 });
      window._piano.onClick(async (midi) => {
        await ensureAudioUnlocked();
        if (window.__robust && window.__robust.playNote) window.__robust.playNote({ midi, velocity: 100, duration: 0.8 });
      });
      console.log("Piano ready");
    } catch (e) { console.warn("Piano init error:", e); }
  }

  // AdvancedMIDIManager or fallback
  if (window.AdvancedMIDIManager) {
    try {
      window._adv = new window.AdvancedMIDIManager();
      await window._adv.init();
      window._adv.on("devicesUpdated", (d) => console.log("MIDI devices", d));
      window._adv.on("midiMessage", async (m) => {
        if (m.type === "noteOn") {
          if (window._piano) { window._piano.setKeyHold(m.note, true); window._piano.highlightKey(m.note, 0.95, 9999); }
          await ensureAudioUnlocked();
          if (window.__robust && window.__robust.playNote) window.__robust.playNote({ midi: m.note, velocity: m.velocity || 90, duration: 0.6 });
        } else if (m.type === "noteOff") {
          if (window._piano) window._piano.setKeyHold(m.note, false);
        }
      });
      console.log("AdvancedMIDIManager ready");
    } catch (e) { console.warn("AdvancedMIDIManager init failed:", e); toast("MIDI init: " + e.message, 4000); }
  } else if (window.MIDIHandler) {
    try {
      const mh = new window.MIDIHandler();
      await mh.init();
      mh.on("noteon", async (d) => { if (window._piano) window._piano.highlightKey(d.note, 0.9, 400); await ensureAudioUnlocked(); if (window.__robust) window.__robust.playNote({ midi:d.note, velocity:d.velocity||90, duration:0.6 }); });
      console.log("MIDIHandler ready");
    } catch (e) { console.warn("MIDIHandler init failed:", e); }
  }

  // UI wiring - non-blocking
  const $ = (id) => document.getElementById(id);
  const btnPlay = $("btn-play"), btnPause = $("btn-pause"), btnStop = $("btn-stop");
  const btnOpen = $("btn-open"), btnGenerate = $("btn-generate");
  const btnRecord = $("btn-record"), btnStopRec = $("btn-stop-record"), btnConnectMidi = $("btn-connect-midi");

  if (btnPlay) btnPlay.addEventListener("click", async () => {
    await ensureAudioUnlocked();
    try {
      if (window.PracticeEngine && window.__practice) { window.__practice.start(); toast("Practice started", 1800); return; }
      toast("Play pressed. (If practice engine available, it will start.)", 2200);
    } catch (e) { toast("Play error: " + e.message, 3500); console.warn(e); }
  });

  if (btnPause) btnPause.addEventListener("click", () => { try { if (window.__practice) { window.__practice.stop(); toast("Paused",1200); } else toast("Pause pressed",1200); } catch(e) { toast("Pause error:"+e.message,3500); } });
  if (btnStop) btnStop.addEventListener("click", () => { try { if (window.__practice) window.__practice.stop(); toast("Stopped",1200); } catch(e){ toast("Stop error:"+e.message,3500); } });

  if (btnOpen) btnOpen.addEventListener("click", async () => {
    try {
      if (!window.api || !window.api.openFolder) return toast("Dialog API missing",2500);
      const res = await window.api.openFolder();
      if (res.canceled) return;
      const folder = res.filePaths[0];
      if (!window.api.loadProject) return toast("loadProject API missing",2500);
      const loadRes = await window.api.loadProject(folder);
      if (!loadRes.ok) { toast("Load failed: " + loadRes.error, 4000); return; }
      console.log("Loaded project:", loadRes.project);
      toast("Project loaded: " + (loadRes.project.title || folder), 2500);
      window.__currentProject = loadRes.project;
    } catch (e) { toast("Open project error: " + e.message, 4000); console.warn(e); }
  });

  if (btnGenerate) btnGenerate.addEventListener("click", async () => {
    try {
      if (!window.api || !window.api.openFile) return toast("Dialog API missing",2500);
      const pick = await window.api.openFile([{ name: "MIDI", extensions: ["mid","midi"] }]);
      if (pick.canceled) return;
      const midiPath = pick.filePaths[0];
      const folderRes = await window.api.openFolder();
      if (folderRes.canceled) return;
      const projectDir = folderRes.filePaths[0];
      toast("Generation started (this may take a moment)...",2500);
      const genRes = await window.api.generateVariants({ projectDir, inputMidiPath: midiPath, options: {} });
      if (!genRes.ok) { toast("Generation failed: " + genRes.error, 5000); console.warn(genRes); return; }
      toast("Generation completed.",3000);
      console.log("Generation result:", genRes.result);
    } catch (e) { toast("Generation error: " + e.message, 5000); console.warn(e); }
  });

  if (btnRecord) btnRecord.addEventListener("click", async () => {
    try { if (window._adv && window._adv.startRecording) { window._adv.startRecording(); toast("Recording started",1800); } else toast("Record not available (MIDI manager missing)",2500); } catch(e) { toast("Record error: " + e.message,4000); }
  });
  if (btnStopRec) btnStopRec.addEventListener("click", () => {
    try { if (window._adv && window._adv.stopRecording) { const rec = window._adv.stopRecording(); toast("Recording stopped. Events: " + (rec.events ? rec.events.length : 0), 3600); } else toast("Stop rec not available",2000); } catch(e) { toast("Stop record error: " + e.message,4000); }
  });

  if (btnConnectMidi) btnConnectMidi.addEventListener("click", async () => {
    try { if (window._adv && window._adv.scanDevices) { window._adv.scanDevices(); toast("Scanned MIDI devices. Check console for details.",2200); return; } toast("MIDI manager not available.",2200); } catch(e) { toast("Connect MIDI error: " + e.message,4000); }
  });

  console.log("Renderer ready and toolbar wired.");
});